Timmy - Timex Computer 2048 clone
--------------------------------------------------------------------------------

(c)2020  McKlaud

Gerbers: rev 0.12
Date:    05/02/2021

--------------------------------------------------------------------------------

This work is licensed under a Creative Commons
Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0).

No Warranty of the Project. The Issuer makes no express or implied warranty of
any kind whatsoever with respect to the Project.

--------------------------------------------------------------------------------

The clone includes:

- Z80A (3.5MHz) CPU
- Timex SCLD
- 16KB lower RAM
- 2 x 32KB upper RAM (bank switching controlled via #FF port)
- 2 x 16KB ROM (selectable)
- AY-3-8910 sound chip controlled via Timex ports
- improved Kempston joystick interface
- RGB and composite video output
- compatible with TC2048 keyboard
- RESET button

PCB in dimensions and size of the TC2048 board
